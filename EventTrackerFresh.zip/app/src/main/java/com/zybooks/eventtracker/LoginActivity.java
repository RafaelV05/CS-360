package com.zybooks.eventtracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private UserDao userDao;
    private EditText etUser, etPass;
    private TextView tvStatus;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        userDao = new UserDao(this);
        etUser = findViewById(R.id.etUser);
        etPass = findViewById(R.id.etPass);
        tvStatus = findViewById(R.id.tvStatus);
        Button btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(v -> tryLogin());
    }

    private void tryLogin() {
        String u = etUser.getText().toString().trim();
        String p = etPass.getText().toString().trim();
        if (u.isEmpty() || p.isEmpty()) {
            tvStatus.setText("Please enter username and password");
            return;
        }
        if (userDao.userExists(u)) {
            if (userDao.validateLogin(u, p)) {
                launchMain();
            } else {
                tvStatus.setText("Incorrect password");
            }
        } else {
            new AlertDialog.Builder(this)
                .setTitle("Create account?")
                .setMessage("No account found for "" + u + "". Create it now?")
                .setPositiveButton("Create", (d, w) -> {
                    long id = userDao.createUser(u, p);
                    if (id > 0) { launchMain(); }
                    else { tvStatus.setText("Could not create account."); }
                })
                .setNegativeButton("Cancel", null)
                .show();
        }
    }

    private void launchMain() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
