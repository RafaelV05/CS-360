package com.zybooks.eventtracker;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsHelper {
    public static final int REQ_SEND_SMS = 2001;

    public static boolean ensurePermission(Activity a) {
        if (ContextCompat.checkSelfPermission(a, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(a, new String[]{Manifest.permission.SEND_SMS}, REQ_SEND_SMS);
            return false;
        }
        return true;
    }

    public static void sendSms(Activity a, String phone, String message) {
        try {
            SmsManager.getDefault().sendTextMessage(phone, null, message, null, null);
            Toast.makeText(a, "SMS sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(a, "SMS failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
