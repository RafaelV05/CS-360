package com.zybooks.eventtracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class UserDao {
    private final DBHelper helper;
    public UserDao(Context ctx) { helper = new DBHelper(ctx); }

    public boolean userExists(String username) {
        try (SQLiteDatabase db = helper.getReadableDatabase();
             Cursor c = db.query(DBHelper.T_USERS, new String[]{DBHelper.C_USER_ID},
                     DBHelper.C_USERNAME + "=?", new String[]{username},
                     null, null, null)) {
            return c.moveToFirst();
        }
    }

    public boolean validateLogin(String username, String password) {
        try (SQLiteDatabase db = helper.getReadableDatabase();
             Cursor c = db.query(DBHelper.T_USERS, new String[]{DBHelper.C_USER_ID},
                     DBHelper.C_USERNAME + "=? AND " + DBHelper.C_PASSWORD + "=?",
                     new String[]{username, password}, null, null, null)) {
            return c.moveToFirst();
        }
    }

    public long createUser(String username, String password) {
        ContentValues cv = new ContentValues();
        cv.put(DBHelper.C_USERNAME, username);
        cv.put(DBHelper.C_PASSWORD, password);
        try (SQLiteDatabase db = helper.getWritableDatabase()) {
            return db.insert(DBHelper.T_USERS, null, cv);
        }
    }
}
