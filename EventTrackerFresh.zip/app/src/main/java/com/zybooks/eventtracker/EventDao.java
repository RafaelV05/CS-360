package com.zybooks.eventtracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;

public class EventDao {
    private final DBHelper helper;
    public EventDao(Context ctx) { helper = new DBHelper(ctx); }

    public long create(String title, String date, String notes, String phone) {
        ContentValues cv = new ContentValues();
        cv.put(DBHelper.C_TITLE, title);
        cv.put(DBHelper.C_DATE, date);
        cv.put(DBHelper.C_NOTES, notes);
        cv.put(DBHelper.C_PHONE, phone);
        try (SQLiteDatabase db = helper.getWritableDatabase()) {
            return db.insert(DBHelper.T_EVENTS, null, cv);
        }
    }

    public int update(long id, String title, String date, String notes, String phone) {
        ContentValues cv = new ContentValues();
        cv.put(DBHelper.C_TITLE, title);
        cv.put(DBHelper.C_DATE, date);
        cv.put(DBHelper.C_NOTES, notes);
        cv.put(DBHelper.C_PHONE, phone);
        try (SQLiteDatabase db = helper.getWritableDatabase()) {
            return db.update(DBHelper.T_EVENTS, cv, DBHelper.C_EVENT_ID + "=?",
                    new String[]{String.valueOf(id)});
        }
    }

    public int delete(long id) {
        try (SQLiteDatabase db = helper.getWritableDatabase()) {
            return db.delete(DBHelper.T_EVENTS, DBHelper.C_EVENT_ID + "=?",
                    new String[]{String.valueOf(id)});
        }
    }

    public List<Event> getAll() {
        List<Event> list = new ArrayList<>();
        try (SQLiteDatabase db = helper.getReadableDatabase();
             Cursor c = db.query(DBHelper.T_EVENTS, null, null, null, null, null, DBHelper.C_DATE + " ASC")) {
            while (c.moveToNext()) {
                long id = c.getLong(c.getColumnIndexOrThrow(DBHelper.C_EVENT_ID));
                String title = c.getString(c.getColumnIndexOrThrow(DBHelper.C_TITLE));
                String date = c.getString(c.getColumnIndexOrThrow(DBHelper.C_DATE));
                String notes = c.getString(c.getColumnIndexOrThrow(DBHelper.C_NOTES));
                String phone = c.getString(c.getColumnIndexOrThrow(DBHelper.C_PHONE));
                list.add(new Event(id, title, date, notes, phone));
            }
        }
        return list;
    }
}
