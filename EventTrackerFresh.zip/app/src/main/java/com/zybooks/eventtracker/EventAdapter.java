package com.zybooks.eventtracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.VH> {
    public interface Callbacks { void onEdit(Event e); void onDelete(Event e); }

    private List<Event> data;
    private final Callbacks cb;

    public EventAdapter(List<Event> data, Callbacks cb) { this.data = data; this.cb = cb; }
    public void setData(List<Event> data) { this.data = data; notifyDataSetChanged(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView title, date, notes;
        ImageButton btnEdit, btnDelete;
        VH(@NonNull View v) {
            super(v);
            title = v.findViewById(R.id.rowTitle);
            date = v.findViewById(R.id.rowDate);
            notes = v.findViewById(R.id.rowNotes);
            btnEdit = v.findViewById(R.id.btnEdit);
            btnDelete = v.findViewById(R.id.btnDelete);
        }
    }

    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_event, parent, false);
        return new VH(v);
    }

    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        Event e = data.get(pos);
        h.title.setText(e.title);
        h.date.setText(e.date);
        h.notes.setText(e.notes == null ? "" : e.notes);
        h.btnEdit.setOnClickListener(v -> cb.onEdit(e));
        h.btnDelete.setOnClickListener(v -> cb.onDelete(e));
    }

    @Override public int getItemCount() { return data == null ? 0 : data.size(); }
}
