package com.zybooks.eventtracker;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements EventAdapter.Callbacks {
    private EventDao eventDao;
    private EventAdapter adapter;
    private List<Event> data = new ArrayList<>();

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        eventDao = new EventDao(this);

        RecyclerView rv = findViewById(R.id.rvEvents);
        rv.setLayoutManager(new GridLayoutManager(this, 2));
        adapter = new EventAdapter(data, this);
        rv.setAdapter(adapter);

        FloatingActionButton fab = findViewById(R.id.fabAdd);
        fab.setOnClickListener(v -> showAddDialog());

        refresh();
    }

    private void refresh() {
        data = eventDao.getAll();
        adapter.setData(data);
    }

    private void showAddDialog() {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_event, null, false);
        new AlertDialog.Builder(this)
            .setTitle("Add Event")
            .setView(view)
            .setPositiveButton("Save", (d, w) -> {
                EditText etTitle = view.findViewById(R.id.etTitle);
                EditText etDate = view.findViewById(R.id.etDate);
                EditText etNotes = view.findViewById(R.id.etNotes);
                EditText etPhone = view.findViewById(R.id.etPhone);
                long id = eventDao.create(
                        etTitle.getText().toString(),
                        etDate.getText().toString(),
                        etNotes.getText().toString(),
                        etPhone.getText().toString()
                );
                if (id > 0) {
                    String phone = etPhone.getText().toString().trim();
                    if (!phone.isEmpty()) {
                        if (SmsHelper.ensurePermission(this)) {
                            SmsHelper.sendSms(this, phone,
                                    "Reminder: " + etTitle.getText().toString() + " on " + etDate.getText().toString());
                        }
                    }
                    Toast.makeText(this, "Added", Toast.LENGTH_SHORT).show();
                    refresh();
                }
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    @Override public void onEdit(Event e) {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_event, null, false);
        ((EditText)view.findViewById(R.id.etTitle)).setText(e.title);
        ((EditText)view.findViewById(R.id.etDate)).setText(e.date);
        ((EditText)view.findViewById(R.id.etNotes)).setText(e.notes);
        ((EditText)view.findViewById(R.id.etPhone)).setText(e.phone);

        new AlertDialog.Builder(this)
            .setTitle("Edit Event")
            .setView(view)
            .setPositiveButton("Update", (d, w) -> {
                EditText etTitle = view.findViewById(R.id.etTitle);
                EditText etDate = view.findViewById(R.id.etDate);
                EditText etNotes = view.findViewById(R.id.etNotes);
                EditText etPhone = view.findViewById(R.id.etPhone);
                int rows = eventDao.update(
                        e.id,
                        etTitle.getText().toString(),
                        etDate.getText().toString(),
                        etNotes.getText().toString(),
                        etPhone.getText().toString()
                );
                if (rows > 0) {
                    Toast.makeText(this, "Updated", Toast.LENGTH_SHORT).show();
                    refresh();
                }
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    @Override public void onDelete(Event e) {
        new AlertDialog.Builder(this)
            .setTitle("Delete event?")
            .setMessage(e.title)
            .setPositiveButton("Delete", (d, w) -> { eventDao.delete(e.id); refresh(); })
            .setNegativeButton("Cancel", null)
            .show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // No special handling needed; if denied, feature remains disabled.
    }
}
