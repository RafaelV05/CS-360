package com.zybooks.eventtracker;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "event_tracker.db";
    public static final int DB_VERSION = 1;

    public static final String T_USERS = "users";
    public static final String C_USER_ID = "_id";
    public static final String C_USERNAME = "username";
    public static final String C_PASSWORD = "password";

    public static final String T_EVENTS = "events";
    public static final String C_EVENT_ID = "_id";
    public static final String C_TITLE = "title";
    public static final String C_DATE = "date";
    public static final String C_NOTES = "notes";
    public static final String C_PHONE = "phone";

    public DBHelper(Context ctx) { super(ctx, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + T_USERS + " (" +
                C_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                C_USERNAME + " TEXT UNIQUE NOT NULL, " +
                C_PASSWORD + " TEXT NOT NULL)");

        db.execSQL("CREATE TABLE " + T_EVENTS + " (" +
                C_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                C_TITLE + " TEXT NOT NULL, " +
                C_DATE + " TEXT NOT NULL, " +
                C_NOTES + " TEXT, " +
                C_PHONE + " TEXT)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS " + T_EVENTS);
        db.execSQL("DROP TABLE IF EXISTS " + T_USERS);
        onCreate(db);
    }
}
