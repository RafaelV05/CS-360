package com.zybooks.eventtracker;

public class Event {
    public long id;
    public String title;
    public String date;
    public String notes;
    public String phone;
    public Event(long id, String title, String date, String notes, String phone) {
        this.id = id; this.title = title; this.date = date; this.notes = notes; this.phone = phone;
    }
}
